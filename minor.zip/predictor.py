# import EmotionRecog

def predict(path):
	print(path + "deepanshu")
